#include <stdio.h>

int main()
{
 	printf("Hola desde C, con NDK de android =)!\n");
	return 0;
}